package com.example.mobile;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class FirstFragment extends Fragment {

    private TextView nameTextView;
    private TextView balanceValueTextView;
    private Button withdrawButton;
    private Button depositButton;
    private DatabaseReference userBalanceRef;
    private FirebaseFirestore firestore;
    private FirebaseAuth firebaseAuth;
    private String currentUserId;
    private Double currentBalance = 0.0;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initialize Firebase Authentication
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();

        if (currentUser != null) {
            currentUserId = currentUser.getUid();
            Log.d(TAG, "Current User ID: " + currentUserId);
        } else {
            // Handle the case where the user is not logged in
            if (getActivity() != null) {
                Toast.makeText(getActivity(), "User not logged in", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "User not logged in");
            }
            // Optionally, redirect to login activity
            return;
        }

        // Initialize Firebase references
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        userBalanceRef = database.getReference("balances").child(currentUserId);
        firestore = FirebaseFirestore.getInstance();

        // Fetch balance data from Firestore
        fetchBalanceFromFirestore();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        // Find the TextViews and Buttons in the fragment layout
        nameTextView = view.findViewById(R.id.name_text_view);
        balanceValueTextView = view.findViewById(R.id.balance_value_text_view);
        withdrawButton = view.findViewById(R.id.withdraw_button);
        depositButton = view.findViewById(R.id.deposit_button);

        // Set up button click listeners
        withdrawButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showWithdrawDialog();
            }
        });

        depositButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDepositDialog();
            }
        });

        // Fetch user's first name and last name from Firestore and display them
        fetchUserDataFromFirestore();

        return view;
    }

    // Fetch balance data from Firestore
    private void fetchBalanceFromFirestore() {
        Log.d(TAG, "Fetching balance for user: " + currentUserId);
        if (currentUserId == null) {
            Log.e(TAG, "currentUserId is null");
            return;
        }

        DocumentReference userDocumentRef = firestore.collection("users").document(currentUserId);
        userDocumentRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document != null && document.exists()) {
                        // Document exists, retrieve balance
                        currentBalance = document.getDouble("balance");
                        Log.d(TAG, "Document data: " + document.getData());
                        if (currentBalance != null) {
                            // Update balance UI
                            Log.d(TAG, "Balance retrieved: " + currentBalance);
                            updateBalanceUI(currentBalance);
                        } else {
                            // Handle case where balance is null
                            Log.e(TAG, "Balance is null in Firestore document");
                            if (getContext() != null) {
                                Toast.makeText(getContext(), "Failed to fetch balance: Balance is null", Toast.LENGTH_SHORT).show();
                            }
                        }
                    } else {
                        // Handle case where document does not exist
                        Log.e(TAG, "Firestore document does not exist for current user: " + currentUserId);
                        if (getContext() != null) {
                            Toast.makeText(getContext(), "Failed to fetch balance: Document does not exist", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    // Handle case where task failed
                    Exception exception = task.getException();
                    if (exception != null) {
                        Log.e(TAG, "Failed to fetch balance from Firestore: " + exception.getMessage());
                        if (getContext() != null) {
                            Toast.makeText(getContext(), "Failed to fetch balance: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Log.e(TAG, "Failed to fetch balance from Firestore: Unknown error");
                        if (getContext() != null) {
                            Toast.makeText(getContext(), "Failed to fetch balance: Unknown error", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }

    // Fetch user's first name and last name from Firestore
    private void fetchUserDataFromFirestore() {
        // Reference to the document containing user's first name and last name
        DocumentReference userDocumentRef = firestore.collection("users").document(currentUserId);

        // Fetch the document
        userDocumentRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document != null && document.exists()) {
                        // Document exists, retrieve first name and last name
                        String firstName = document.getString("first_name");
                        String lastName = document.getString("last_name");

                        // Convert first name and last name to uppercase
                        String upperCaseFirstName = firstName != null ? firstName.toUpperCase() : "";
                        String upperCaseLastName = lastName != null ? lastName.toUpperCase() : "";

                        // Update the TextView with first name and last name combined with one space

                        if (firstName != null && lastName != null) {
                            // Combine first name and last name with a space
                            String fullName = upperCaseFirstName + " " + upperCaseLastName;
                            nameTextView.setText(fullName);
                        }
                    } else {
                        Log.e(TAG, "Firestore document does not exist for current user: " + currentUserId);
                        if (getContext() != null) {
                            Toast.makeText(getContext(), "Failed to fetch user's name: Document does not exist", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Exception exception = task.getException();
                    if (exception != null) {
                        Log.e(TAG, "Failed to fetch user's name from Firestore: " + exception.getMessage());
                        if (getContext() != null) {
                            Toast.makeText(getContext(), "Failed to fetch user's name: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Log.e(TAG, "Failed to fetch user's name from Firestore: Unknown error");
                        if (getContext() != null) {
                            Toast.makeText(getContext(), "Failed to fetch user's name: Unknown error", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }

    // Method to update the UI with the retrieved balance value
    private void updateBalanceUI(Double balance) {
        if (balance != null) {
            // Update TextView with the retrieved balance value
            balanceValueTextView.setText(String.valueOf(balance));
        } else {
            // If balance is null, display "N/A"
            Log.e(TAG, "Received null balance value");
            if (getContext() != null) {
                Toast.makeText(getContext(), "Received null balance value", Toast.LENGTH_SHORT).show();
            }
            balanceValueTextView.setText("N/A");
        }
    }

    // Method to show the withdrawal dialog
    private void showWithdrawDialog() {
        // Inflate the withdrawal layout
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_withdraw, null);

        // Find EditTexts in the withdrawal layout
        EditText amountEditText = dialogView.findViewById(R.id.amount_edit_text);
        EditText recipientEditText = dialogView.findViewById(R.id.recipient_email_edit_text);

        // Create AlertDialog Builder
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Withdraw")
                .setView(dialogView)
                .setPositiveButton("Withdraw", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Retrieve amount and recipient email
                        String amountString = amountEditText.getText().toString().trim();
                        String recipientEmail = recipientEditText.getText().toString().trim();

                        // Validate input fields
                        if (amountString.isEmpty() || recipientEmail.isEmpty()) {
                            Toast.makeText(getContext(), "Please enter amount and recipient email", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        // Convert amountString to Double
                        Double amount = Double.parseDouble(amountString);

                        // Perform withdrawal logic
                        withdrawAmount(amount, recipientEmail);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Cancel withdrawal
                        dialog.dismiss();
                    }
                });

        // Show AlertDialog
        builder.create().show();
    }

    private void withdrawAmount(Double amount, String recipientEmail) {
        // Step 1: Validate if the withdrawal amount is not greater than the current account balance
        if (currentBalance < amount) {
            // Insufficient balance, display error message
            Toast.makeText(getContext(), "Insufficient balance", Toast.LENGTH_SHORT).show();
            return;
        }

        // Step 2: Deduct the withdrawal amount from the current user's account balance in Firestore
        deductFromCurrentUserBalance(amount, recipientEmail);
    }

    // Method to deduct the withdrawal amount from the current user's account balance in Firestore
    private void deductFromCurrentUserBalance(Double amount, String recipientEmail) {
        firestore.collection("users")
                .whereEqualTo("email", firebaseAuth.getCurrentUser().getEmail())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String currentUserId = document.getId();
                                Double currentAccountBalance = document.getDouble("balance");
                                if (currentAccountBalance != null) {
                                    Double newBalance = currentAccountBalance - amount;
                                    firestore.collection("users").document(currentUserId).update("balance", newBalance)
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    // Update current user's balance after successful withdrawal
                                                    currentBalance -= amount;
                                                    updateBalanceUI(currentBalance);
                                                    Toast.makeText(getContext(), "Withdrawal successful", Toast.LENGTH_SHORT).show();

                                                    // Step 3: Update the balance of the recipient's account in Firestore
                                                    updateRecipientBalance(recipientEmail, amount);
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(getContext(), "Failed to update balance", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                } else {
                                    Toast.makeText(getContext(), "Current user balance is null", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {
                            Toast.makeText(getContext(), "Error fetching current user balance", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    // Method to update the balance of the recipient's account in Firestore
    private void updateRecipientBalance(String recipientEmail, Double amount) {
        firestore.collection("users")
                .whereEqualTo("email", recipientEmail)
                .get()
                .addOnCompleteListener(new OnCompleteListener<
                        QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String recipientUserId = document.getId();
                                Double recipientBalance = document.getDouble("balance");
                                if (recipientBalance != null) {
                                    Double newBalance = recipientBalance + amount;
                                    firestore.collection("users").document(recipientUserId).update("balance", newBalance)
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    Toast.makeText(getContext(), "Recipient balance updated", Toast.LENGTH_SHORT).show();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(getContext(), "Failed to update recipient balance", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                } else {
                                    Toast.makeText(getContext(), "Recipient balance is null", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {
                            Toast.makeText(getContext(), "Error fetching recipient balance", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    // Method to show the deposit dialog
    private void showDepositDialog() {
        // Inflate the deposit layout
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_deposit, null);

        // Find EditText in the deposit layout
        EditText amountEditText = dialogView.findViewById(R.id.amount_edit_text);

        // Create AlertDialog Builder
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Deposit")
                .setView(dialogView)
                .setPositiveButton("Deposit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Retrieve deposit amount
                        String amountString = amountEditText.getText().toString().trim();

                        // Validate input field
                        if (amountString.isEmpty()) {
                            Toast.makeText(getContext(), "Please enter amount", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        // Convert amountString to Double
                        Double amount = Double.parseDouble(amountString);

                        // Perform deposit logic
                        depositAmount(amount);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Cancel deposit
                        dialog.dismiss();
                    }
                });

        // Show AlertDialog
        builder.create().show();
    }

    // Method to deposit the given amount into the current user's account balance in Firestore
    private void depositAmount(Double amount) {
        firestore.collection("users")
                .whereEqualTo("email", firebaseAuth.getCurrentUser().getEmail())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String currentUserId = document.getId();
                                Double currentAccountBalance = document.getDouble("balance");
                                if (currentAccountBalance != null) {
                                    Double newBalance = currentAccountBalance + amount;
                                    firestore.collection("users").document(currentUserId).update("balance", newBalance)
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    // Update current user's balance after successful deposit
                                                    currentBalance += amount;
                                                    updateBalanceUI(currentBalance);
                                                    Toast.makeText(getContext(), "Deposit successful", Toast.LENGTH_SHORT).show();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(getContext(), "Failed to update balance", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                } else {
                                    Toast.makeText(getContext(), "Current user balance is null", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {
                            Toast.makeText(getContext(), "Error fetching current user balance", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}

package com.example.mobile;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Registration extends AppCompatActivity {

    Spinner spinner;
    String gender = "";
    String birthday_save = "";
    TextView birthday;

    FirebaseFirestore db;
    private static final String TAG = "Registration";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);

        EditText emailOrPhoneEditText = findViewById(R.id.emailOrPhoneEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);
        EditText firstname = findViewById(R.id.firstNameEditText);
        EditText second_name = findViewById(R.id.lastNameEditText);
        Button signUpButton = findViewById(R.id.signUpButton);
        TextView have_acc=findViewById(R.id.have_acc);
      //  Button login_btn=findViewById(R.id.login_btn);
       //birthday = findViewById(R.id.birthdayEditText);
        db = FirebaseFirestore.getInstance();
       // spinner = findViewById(R.id.spinner);

        //ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
          //      R.array.spinner_items, android.R.layout.simple_spinner_item);
        //adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //spinner.setAdapter(adapter);

       have_acc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Registration.this, Login_page.class));
            }
        });
     /*   birthday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });*/

      /*  spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                gender = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });*/

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailOrPhoneEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString();
                String fname = firstname.getText().toString();
                String sname = second_name.getText().toString();

                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password).addOnCompleteListener(Registration.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Successfully created user, now add data to Firestore
                            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                            if (currentUser != null) {
                                String uid = currentUser.getUid();
                                Log.d(TAG, "Current User ID: " + uid);
                                addData(uid, fname, sname, gender, birthday_save, email);
                            }
                            Toast.makeText(Registration.this, "Register ok", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Registration.this, Login_page.class));
                        } else {
                            String errorMessage = task.getException().getMessage();
                            Toast.makeText(Registration.this, "Registration failed: " + errorMessage, Toast.LENGTH_SHORT).show();
                            Log.e(TAG, "Registration failed", task.getException());
                        }
                    }
                });
            }
        });
    }

    private void addData(String uid, String first_name, String last_name, String gender, String dob, String email) {
        Map<String, Object> user = new HashMap<>();
        user.put("balance", 0.0); // Set initial balance to 0.0
        user.put("first_name", first_name);
        user.put("last_name", last_name);
        user.put("gender", gender);
        user.put("date_of_birth", dob);
        user.put("email", email);

        db.collection("users")
                .document(uid)
                .set(user)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "DocumentSnapshot added with ID: " + uid);
                        } else {
                            Log.e(TAG, "Error adding document", task.getException());
                        }
                    }
                });
    }
}

package com.example.mobile;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class Splash_screen extends Activity {

    private static int SPLASH_TIME_OUT = 3000; // 3 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        ImageView splashLogo = findViewById(R.id.splash_logo);
        Glide.with(Splash_screen.this).asGif().load(R.drawable.splashed).into(splashLogo);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Splash_screen.this, Registration.class);
                startActivity(i);
                finish();
            }
        }, SPLASH_TIME_OUT);
    }
}

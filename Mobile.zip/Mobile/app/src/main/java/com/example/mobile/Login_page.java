package com.example.mobile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login_page extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        TextView have_no_acc =findViewById(R.id.have_no_acc);
        EditText usernameEditText=findViewById(R.id.usernameEditText);
        EditText passwordEditText=findViewById(R.id.passwordEditText);
        Button loginButton=findViewById(R.id.loginButton);
        have_no_acc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Login_page.this, Registration.class);
                startActivity(intent);
            }

        });
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email=usernameEditText.getText().toString();
                String password=passwordEditText.getText().toString();
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(Login_page.this, "login Successful", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Login_page.this, MainActivity.class));
                        }
                        else
                        {
                            //Toast.makeText(Login_page.this, "Error", Toast.LENGTH_SHORT).show();
                            Toast.makeText(Login_page.this, "Login Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
        });
    }
}
package com.example.mobile;


import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        // Set the default selected item and fragment
        if (savedInstanceState == null) {
            bottomNavigationView.setSelectedItemId(R.id.person);
            setCurrentFragment(new FirstFragment());
        }
    }

    private void setCurrentFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, fragment).commit();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.person) {
            setCurrentFragment(new FirstFragment());
        } else if (itemId == R.id.home) {
            setCurrentFragment(new SecondFragment());
        } else if (itemId == R.id.settings) {
            setCurrentFragment(new ThirdFragment());
        }





        return false;
    }
}
